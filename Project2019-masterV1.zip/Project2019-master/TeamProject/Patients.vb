﻿Public Class Patients
    Private Sub btnOther_CheckedChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub cbxIllness_DropDownClosed(sender As Object, e As EventArgs) Handles cbxIllness.DropDownClosed
        If (cbxIllness.SelectedIndex = 2) Then
            txtOther.Enabled = True
        End If
    End Sub

    Private Sub btnAddP_Click(sender As Object, e As EventArgs) Handles btnAddP.Click

        'Verify that the ID is valid
        'If not throw exception that tells user it isnt valid

        'Import all data to database

        Hospital.Visible = True
        Me.Close()
    End Sub

    Private Sub mcApp_DateSelected(sender As Object, e As DateRangeEventArgs) Handles mcApp.DateSelected
        'check if date is available and display a popup if not
    End Sub

    Private Sub btnGoBack_Click(sender As Object, e As EventArgs) Handles btnGoBack.Click
        'Me.Close()
    End Sub
End Class