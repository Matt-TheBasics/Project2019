﻿Public Class Add_Medication
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        'imports medication into database
    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        'Go back to previous window
        Me.Close()
    End Sub
End Class