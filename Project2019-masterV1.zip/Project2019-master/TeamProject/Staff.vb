﻿Imports System.Data.OleDb

Public Class Staff

    Dim daTables As OleDbDataAdapter
    Dim dsTables As DataSet
    Dim simpleC As Integer = 0

    Private Sub btnStaff_CheckedChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub Staff_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'SHHDataSet.Nurses' table. You can move, or remove it, as needed.
        Me.NursesTableAdapter.Fill(Me.SHHDataSet.Nurses)
        'TODO: This line of code loads data into the 'SHHDataSet.Doctors' table. You can move, or remove it, as needed.
        Me.DoctorsTableAdapter.Fill(Me.SHHDataSet.Doctors)

    End Sub

    Private Sub btnAddDoc_Click(sender As Object, e As EventArgs) Handles btnAddDoc.Click
        Add_staff.ShowDialog()
    End Sub

    Private Sub btnDorN_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub btnMedications_Click(sender As Object, e As EventArgs) Handles btnMedications.Click
        Medications.ShowDialog()
    End Sub

    Private Sub btnGoBack_Click(sender As Object, e As EventArgs) Handles btnGoBack.Click
        Me.Close()
    End Sub
End Class