﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Staff
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.dgvDoctors = New System.Windows.Forms.DataGridView()
        Me.IDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DoctorsBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.SHHDataSet = New TeamProject.SHHDataSet()
        Me.DoctorsTableAdapter = New TeamProject.SHHDataSetTableAdapters.DoctorsTableAdapter()
        Me.btnAddDoc = New System.Windows.Forms.Button()
        Me.NursesBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.NursesTableAdapter = New TeamProject.SHHDataSetTableAdapters.NursesTableAdapter()
        Me.btnMedications = New System.Windows.Forms.Button()
        Me.btnGoBack = New System.Windows.Forms.Button()
        CType(Me.dgvDoctors, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DoctorsBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SHHDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NursesBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dgvDoctors
        '
        Me.dgvDoctors.AllowUserToAddRows = False
        Me.dgvDoctors.AllowUserToDeleteRows = False
        Me.dgvDoctors.AutoGenerateColumns = False
        Me.dgvDoctors.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvDoctors.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.IDDataGridViewTextBoxColumn})
        Me.dgvDoctors.DataSource = Me.DoctorsBindingSource
        Me.dgvDoctors.Location = New System.Drawing.Point(3, 2)
        Me.dgvDoctors.Name = "dgvDoctors"
        Me.dgvDoctors.Size = New System.Drawing.Size(868, 443)
        Me.dgvDoctors.TabIndex = 1
        '
        'IDDataGridViewTextBoxColumn
        '
        Me.IDDataGridViewTextBoxColumn.DataPropertyName = "ID"
        Me.IDDataGridViewTextBoxColumn.HeaderText = "ID"
        Me.IDDataGridViewTextBoxColumn.Name = "IDDataGridViewTextBoxColumn"
        '
        'DoctorsBindingSource
        '
        Me.DoctorsBindingSource.DataMember = "Doctors"
        Me.DoctorsBindingSource.DataSource = Me.SHHDataSet
        '
        'SHHDataSet
        '
        Me.SHHDataSet.DataSetName = "SHHDataSet"
        Me.SHHDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'DoctorsTableAdapter
        '
        Me.DoctorsTableAdapter.ClearBeforeFill = True
        '
        'btnAddDoc
        '
        Me.btnAddDoc.Location = New System.Drawing.Point(157, 451)
        Me.btnAddDoc.Name = "btnAddDoc"
        Me.btnAddDoc.Size = New System.Drawing.Size(148, 23)
        Me.btnAddDoc.TabIndex = 2
        Me.btnAddDoc.Text = "Add Worker"
        Me.btnAddDoc.UseVisualStyleBackColor = True
        '
        'NursesBindingSource
        '
        Me.NursesBindingSource.DataMember = "Nurses"
        Me.NursesBindingSource.DataSource = Me.SHHDataSet
        '
        'NursesTableAdapter
        '
        Me.NursesTableAdapter.ClearBeforeFill = True
        '
        'btnMedications
        '
        Me.btnMedications.Location = New System.Drawing.Point(311, 450)
        Me.btnMedications.Name = "btnMedications"
        Me.btnMedications.Size = New System.Drawing.Size(134, 24)
        Me.btnMedications.TabIndex = 5
        Me.btnMedications.Text = "Medication"
        Me.btnMedications.UseVisualStyleBackColor = True
        '
        'btnGoBack
        '
        Me.btnGoBack.Location = New System.Drawing.Point(737, 450)
        Me.btnGoBack.Name = "btnGoBack"
        Me.btnGoBack.Size = New System.Drawing.Size(134, 24)
        Me.btnGoBack.TabIndex = 6
        Me.btnGoBack.Text = "Go Back"
        Me.btnGoBack.UseVisualStyleBackColor = True
        '
        'Staff
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(874, 492)
        Me.Controls.Add(Me.btnGoBack)
        Me.Controls.Add(Me.btnMedications)
        Me.Controls.Add(Me.btnAddDoc)
        Me.Controls.Add(Me.dgvDoctors)
        Me.Name = "Staff"
        Me.Text = "Staff"
        CType(Me.dgvDoctors, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DoctorsBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SHHDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NursesBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents dgvDoctors As DataGridView
    Friend WithEvents SHHDataSet As SHHDataSet
    Friend WithEvents DoctorsBindingSource As BindingSource
    Friend WithEvents DoctorsTableAdapter As SHHDataSetTableAdapters.DoctorsTableAdapter
    Friend WithEvents btnAddDoc As Button
    Friend WithEvents IDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents NursesBindingSource As BindingSource
    Friend WithEvents NursesTableAdapter As SHHDataSetTableAdapters.NursesTableAdapter
    Friend WithEvents btnMedications As Button
    Friend WithEvents btnGoBack As Button
End Class
