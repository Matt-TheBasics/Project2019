﻿Public Class Add_Medication
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        'imports medication into database
        Dim mName As String = txtName.Text
        Dim aIng As String = txtAcIg.Text
        Dim iSchedule As Integer = CInt(nudSchedule.Value)
        Dim rDate As String = mcReceived.SelectionRange.Start.ToShortDateString()
        Dim sIllness As String
        If (cbxIllness.SelectedIndex = 2) Then
            sIllness = txtOther.Text
        Else
            sIllness = cbxIllness.SelectedValue
        End If
        Dim sRem As Integer = CInt(txtStock.Text)
        Try
            Dim sqlconn As New OleDb.OleDbConnection
            Dim sqlquery As New OleDb.OleDbCommand
            Dim connString As String
            connString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=SHH.mdb"
            sqlconn.ConnectionString = connString
            sqlquery.Connection = sqlconn
            sqlconn.Open()
            sqlquery.CommandText = "INSERT INTO Medication([Name], [ActiveIngredient], [Schedule], [DateReceived], [Illness], [StockRemaining])VALUES(@Name, @ActiveIngredient, @Schedule, @DateReceived, @Illness, @StockRemaining)"
            sqlquery.Parameters.AddWithValue("@Name", mName)
            sqlquery.Parameters.AddWithValue("@ActiveIngredient", aIng)
            sqlquery.Parameters.AddWithValue("@Schedule", iSchedule)
            sqlquery.Parameters.AddWithValue("@DateReceived", rDate)
            sqlquery.Parameters.AddWithValue("@Illness", sIllness)
            sqlquery.Parameters.AddWithValue("@StockRemaining", sRem)
            sqlquery.ExecuteNonQuery()
            sqlconn.Close()

            MessageBox.Show("Medication added successfully!")
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        'Go back to previous window
        Me.Close()
    End Sub

    Private Sub cbxIllness_DropDownClosed(sender As Object, e As EventArgs) Handles cbxIllness.DropDownClosed
        If (cbxIllness.SelectedIndex = 2) Then
            txtOther.Enabled = True
        End If
    End Sub
End Class