﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Medications
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.SHHDataSetBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.SHHDataSet = New TeamProject.SHHDataSet()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.btnGoBack = New System.Windows.Forms.Button()
        Me.DataSetReal = New TeamProject.DataSetReal()
        Me.MedicationBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.MedicationTableAdapter = New TeamProject.DataSetRealTableAdapters.MedicationTableAdapter()
        Me.IDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ActiveIngredientDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ScheduleDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DateReceivedDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.IllnessDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StockRemainingDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SHHDataSetBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SHHDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataSetReal, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MedicationBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.IDDataGridViewTextBoxColumn, Me.NameDataGridViewTextBoxColumn, Me.ActiveIngredientDataGridViewTextBoxColumn, Me.ScheduleDataGridViewTextBoxColumn, Me.DateReceivedDataGridViewTextBoxColumn, Me.IllnessDataGridViewTextBoxColumn, Me.StockRemainingDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.MedicationBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(12, 12)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(499, 310)
        Me.DataGridView1.TabIndex = 0
        '
        'SHHDataSetBindingSource
        '
        Me.SHHDataSetBindingSource.DataSource = Me.SHHDataSet
        Me.SHHDataSetBindingSource.Position = 0
        '
        'SHHDataSet
        '
        Me.SHHDataSet.DataSetName = "SHHDataSet"
        Me.SHHDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(12, 327)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(139, 26)
        Me.btnAdd.TabIndex = 1
        Me.btnAdd.Text = "Add medication"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'btnGoBack
        '
        Me.btnGoBack.Location = New System.Drawing.Point(372, 327)
        Me.btnGoBack.Name = "btnGoBack"
        Me.btnGoBack.Size = New System.Drawing.Size(139, 26)
        Me.btnGoBack.TabIndex = 2
        Me.btnGoBack.Text = "Go Back"
        Me.btnGoBack.UseVisualStyleBackColor = True
        '
        'DataSetReal
        '
        Me.DataSetReal.DataSetName = "DataSetReal"
        Me.DataSetReal.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'MedicationBindingSource
        '
        Me.MedicationBindingSource.DataMember = "Medication"
        Me.MedicationBindingSource.DataSource = Me.DataSetReal
        '
        'MedicationTableAdapter
        '
        Me.MedicationTableAdapter.ClearBeforeFill = True
        '
        'IDDataGridViewTextBoxColumn
        '
        Me.IDDataGridViewTextBoxColumn.DataPropertyName = "ID"
        Me.IDDataGridViewTextBoxColumn.HeaderText = "ID"
        Me.IDDataGridViewTextBoxColumn.Name = "IDDataGridViewTextBoxColumn"
        '
        'NameDataGridViewTextBoxColumn
        '
        Me.NameDataGridViewTextBoxColumn.DataPropertyName = "Name"
        Me.NameDataGridViewTextBoxColumn.HeaderText = "Name"
        Me.NameDataGridViewTextBoxColumn.Name = "NameDataGridViewTextBoxColumn"
        '
        'ActiveIngredientDataGridViewTextBoxColumn
        '
        Me.ActiveIngredientDataGridViewTextBoxColumn.DataPropertyName = "ActiveIngredient"
        Me.ActiveIngredientDataGridViewTextBoxColumn.HeaderText = "ActiveIngredient"
        Me.ActiveIngredientDataGridViewTextBoxColumn.Name = "ActiveIngredientDataGridViewTextBoxColumn"
        '
        'ScheduleDataGridViewTextBoxColumn
        '
        Me.ScheduleDataGridViewTextBoxColumn.DataPropertyName = "Schedule"
        Me.ScheduleDataGridViewTextBoxColumn.HeaderText = "Schedule"
        Me.ScheduleDataGridViewTextBoxColumn.Name = "ScheduleDataGridViewTextBoxColumn"
        '
        'DateReceivedDataGridViewTextBoxColumn
        '
        Me.DateReceivedDataGridViewTextBoxColumn.DataPropertyName = "DateReceived"
        Me.DateReceivedDataGridViewTextBoxColumn.HeaderText = "DateReceived"
        Me.DateReceivedDataGridViewTextBoxColumn.Name = "DateReceivedDataGridViewTextBoxColumn"
        '
        'IllnessDataGridViewTextBoxColumn
        '
        Me.IllnessDataGridViewTextBoxColumn.DataPropertyName = "Illness"
        Me.IllnessDataGridViewTextBoxColumn.HeaderText = "Illness"
        Me.IllnessDataGridViewTextBoxColumn.Name = "IllnessDataGridViewTextBoxColumn"
        '
        'StockRemainingDataGridViewTextBoxColumn
        '
        Me.StockRemainingDataGridViewTextBoxColumn.DataPropertyName = "StockRemaining"
        Me.StockRemainingDataGridViewTextBoxColumn.HeaderText = "StockRemaining"
        Me.StockRemainingDataGridViewTextBoxColumn.Name = "StockRemainingDataGridViewTextBoxColumn"
        '
        'Medications
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(523, 365)
        Me.Controls.Add(Me.btnGoBack)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.DataGridView1)
        Me.Name = "Medications"
        Me.Text = "Medications"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SHHDataSetBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SHHDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataSetReal, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MedicationBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents btnAdd As Button
    Friend WithEvents btnGoBack As Button
    Friend WithEvents SHHDataSetBindingSource As BindingSource
    Friend WithEvents SHHDataSet As SHHDataSet
    Friend WithEvents DataSetReal As DataSetReal
    Friend WithEvents MedicationBindingSource As BindingSource
    Friend WithEvents MedicationTableAdapter As DataSetRealTableAdapters.MedicationTableAdapter
    Friend WithEvents IDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents NameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ActiveIngredientDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ScheduleDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DateReceivedDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents IllnessDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents StockRemainingDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
End Class
