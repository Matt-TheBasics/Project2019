﻿
Public Class Hospital
    Private Sub btnStaff_Click(sender As Object, e As EventArgs) Handles btnStaff.Click
        Login.ShowDialog()
    End Sub

    Private Sub btnPatient_Click(sender As Object, e As EventArgs) Handles btnPatient.Click
        Patients.ShowDialog()
    End Sub
End Class
