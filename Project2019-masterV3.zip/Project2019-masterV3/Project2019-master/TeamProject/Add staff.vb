﻿Public Class Add_staff
    Private Sub btnGoBack_Click(sender As Object, e As EventArgs) Handles btnGoBack.Click
        Me.Close()
    End Sub

    Private Sub btnAddS_Click(sender As Object, e As EventArgs) Handles btnAddS.Click
        Dim sName As String
        Dim sSurname As String
        Dim sDoB As String
        Dim sID As String
        Dim sJobTitle As String

        sName = txtName.Text
        sSurname = txtSurname.Text
        sDoB = dtpDoB.Value.ToShortDateString()
        sID = txtID.Text
        sJobTitle = cbxJob.SelectedItem.ToString()

        If (validateID(sID) = True) Then
            Dim tempIDString As String = sID.Substring(0, 5)
            Dim tempDateString As String = sDoB.Replace("/", "")
            tempDateString = tempDateString.Substring(2, 7)
            If (tempDateString = tempIDString) Then
                Select Case sJobTitle
                    Case "Doctor"
                        Try
                            Dim sqlconn As New OleDb.OleDbConnection
                            Dim sqlquery As New OleDb.OleDbCommand
                            Dim connString As String
                            connString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=SHH.mdb"
                            sqlconn.ConnectionString = connString
                            sqlquery.Connection = sqlconn
                            sqlconn.Open()
                            sqlquery.CommandText = "INSERT INTO Doctors([DName], [DSurname], [DSpec], [DAvailable])VALUES(@DName, @DSurname, @DSpec, @DAvailable)"
                            sqlquery.Parameters.AddWithValue("@DName", sName)
                            sqlquery.Parameters.AddWithValue("@DSurname", sSurname)
                            sqlquery.Parameters.AddWithValue("@DSpec", "GP")
                            sqlquery.Parameters.AddWithValue("@DAvailable", "Yes")
                            sqlquery.ExecuteNonQuery()
                            sqlconn.Close()

                            MessageBox.Show("Doctor added successfully!")
                        Catch ex As Exception
                            MessageBox.Show(ex.Message)
                        End Try
                    Case "Nurse"
                        Try
                            Dim sqlconn As New OleDb.OleDbConnection
                            Dim sqlquery As New OleDb.OleDbCommand
                            Dim connString As String
                            connString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=SHH.mdb"
                            sqlconn.ConnectionString = connString
                            sqlquery.Connection = sqlconn
                            sqlconn.Open()
                            sqlquery.CommandText = "INSERT INTO Nurses([NName], [NSurname], [NHead])VALUES(@NName, @NSurname, @NHead)"
                            sqlquery.Parameters.AddWithValue("@NName", sName)
                            sqlquery.Parameters.AddWithValue("@NSurname", sSurname)
                            sqlquery.Parameters.AddWithValue("@NHead", "No")
                            sqlquery.ExecuteNonQuery()
                            sqlconn.Close()

                            MessageBox.Show("Medication added successfully!")
                        Catch ex As Exception
                            MessageBox.Show(ex.Message)
                        End Try
                    Case "Handyman"
                        Try
                            Dim sqlconn As New OleDb.OleDbConnection
                            Dim sqlquery As New OleDb.OleDbCommand
                            Dim connString As String
                            connString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=SHH.mdb"
                            sqlconn.ConnectionString = connString
                            sqlquery.Connection = sqlconn
                            sqlconn.Open()
                            sqlquery.CommandText = "INSERT INTO Handyman([hName], [hSurname], [hDoB], [hID])VALUES(@hName, @hSurname, @hDoB, @hID)"
                            sqlquery.Parameters.AddWithValue("@hName", sName)
                            sqlquery.Parameters.AddWithValue("@hSurname", sSurname)
                            sqlquery.Parameters.AddWithValue("@hDoB", sDoB)
                            sqlquery.Parameters.AddWithValue("@hID", sID)
                            sqlquery.ExecuteNonQuery()
                            sqlconn.Close()

                            MessageBox.Show("Medication added successfully!")
                        Catch ex As Exception
                            MessageBox.Show(ex.Message)
                        End Try
                End Select
            End If
        Else

            MessageBox.Show("Please enter a valid ID!")
        End If

        MessageBox.Show(sName + vbLf + sSurname + vbLf + sDoB + vbLf + sID + vbLf + sJobTitle)

    End Sub

    Private Function validateID(ByVal sID As String) As Boolean
        Try
            Dim a As Integer = 0
            For i As Integer = 0 To 5
                a += CInt(sID.Substring(i * 2, 1))
            Next

            Dim b As Integer = 0
            For i As Integer = 0 To 5
                b = b * 10 + CInt(sID.Substring(2 * i + 1, 1))
            Next
            b *= 2
            Dim c As Integer = 0
            Do
                c += b Mod 10
                b = Int(b / 10)
            Loop Until b <= 0
            c += a
            Dim d As Integer = 0
            d = 10 - (c Mod 10)
            If (d = 10) Then d = 0
            If d = CInt(sID.Substring(12, 1)) Then
                Return True
            Else
                Return False
            End If
        Catch
            Return False
        End Try
    End Function
End Class