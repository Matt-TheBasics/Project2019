﻿Option Explicit On
Option Strict On
Option Infer Off

Public Class frmLogin
    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click

        'username and password are fixed as discussed

        Dim Username As String = "Gw2q!22"
        Dim Password As String = "Y3Wa#2&q"

        If txtPassword.Text <> Password Or txtUsername.Text <> Username Then
            MsgBox("Wrong Password or Username!!!", MsgBoxStyle.Exclamation And MsgBoxStyle.RetryCancel, "Warning")
        Else
            MsgBox("Welcome Head Nurse!", MsgBoxStyle.OkOnly And MsgBoxStyle.Information)
        End If
    End Sub
End Class
