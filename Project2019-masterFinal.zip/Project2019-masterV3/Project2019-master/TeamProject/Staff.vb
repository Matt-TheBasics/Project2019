﻿Imports System.Data.OleDb

Public Class Staff

    Dim daTables As OleDbDataAdapter
    Dim dsTables As DataSet
    Dim simpleC As Integer = 0


    Private Sub btnStaff_CheckedChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub Staff_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'SHHDataSetFinal.Nurses' table. You can move, or remove it, as needed.
        Me.NursesTableAdapter2.Fill(Me.SHHDataSetFinal.Nurses)
    End Sub

    Private Sub btnAddDoc_Click(sender As Object, e As EventArgs) Handles btnAddDoc.Click
        Add_staff.ShowDialog()
    End Sub

    Private Sub btnDorN_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub btnMedications_Click(sender As Object, e As EventArgs) Handles btnMedications.Click
        Medications.ShowDialog()
    End Sub

    Private Sub btnGoBack_Click(sender As Object, e As EventArgs) Handles btnGoBack.Click
        Me.Close()
    End Sub

    Private Sub btnSwap_Click(sender As Object, e As EventArgs) Handles btnSwap.Click
        If (simpleC Mod 2 = 0) Then
            'TODO: This line of code loads data into the 'SHHDataSetFinal.Doctors' table. You can move, or remove it, as needed.
            Me.DoctorsTableAdapter2.Fill(Me.SHHDataSetFinal.Doctors)
            dgvDoctors.Update()
        ElseIf (simpleC Mod 3 = 0) Then
            'TODO: This line of code loads data into the 'SHHDataSetFinal.Handyman' table. You can move, or remove it, as needed.
            Me.HandymanTableAdapter.Fill(Me.SHHDataSetFinal.Handyman)
            dgvDoctors.Update()
        Else
            Me.NursesTableAdapter2.Fill(Me.SHHDataSetFinal.Nurses)
            dgvDoctors.Update()
        End If
        simpleC += 1

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnCalcSalary.Click
        Try
            Dim DHours As Integer = CInt(InputBox("How many overtime hours has the doctor worked?"))
            Dim HNSalary As Integer = CInt(InputBox("What is the Salary of the head nurse?"))
            Dim Nurses As Integer = CInt(InputBox("How many nurses are at the clinic?"))
            Dim NurseDays As Integer = CInt(InputBox("Total days each nurse has worked?"))
            Dim Maintenance As Integer = CInt(InputBox("Total days worked by maintenance?"))
            Dim Specialist As Boolean
            Dim Flag As String = InputBox("Was there need for a specialist? (Yes / No)")
            Dim objSalaries As New Salaries(DHours, HNSalary, NurseDays, Nurses, Maintenance, Specialist)
            txtSalaryTotal.Text = CStr(objSalaries.CalcTotal())

            If UCase(Flag) = "YES" Then
                Specialist = True
            Else
                Specialist = False
            End If

        Catch ex As Exception
            MessageBox.Show("Exception thrown: No valid value entered!" & vbLf & "Please enter a valid value")

        End Try





    End Sub
End Class