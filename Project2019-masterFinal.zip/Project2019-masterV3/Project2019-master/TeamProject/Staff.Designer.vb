﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Staff
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.dgvDoctors = New System.Windows.Forms.DataGridView()
        Me.NursesBindingSource2 = New System.Windows.Forms.BindingSource(Me.components)
        Me.SHHDataSetFinal = New TeamProject.SHHDataSetFinal()
        Me.DoctorsBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.DataSetReal = New TeamProject.DataSetReal()
        Me.DoctorsBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.SHHDataSet = New TeamProject.SHHDataSet()
        Me.DoctorsTableAdapter = New TeamProject.SHHDataSetTableAdapters.DoctorsTableAdapter()
        Me.btnAddDoc = New System.Windows.Forms.Button()
        Me.NursesBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.NursesTableAdapter = New TeamProject.SHHDataSetTableAdapters.NursesTableAdapter()
        Me.btnMedications = New System.Windows.Forms.Button()
        Me.btnGoBack = New System.Windows.Forms.Button()
        Me.DoctorsTableAdapter1 = New TeamProject.DataSetRealTableAdapters.DoctorsTableAdapter()
        Me.btnSwap = New System.Windows.Forms.Button()
        Me.NursesBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.NursesTableAdapter1 = New TeamProject.DataSetRealTableAdapters.NursesTableAdapter()
        Me.DoctorsBindingSource2 = New System.Windows.Forms.BindingSource(Me.components)
        Me.DoctorsTableAdapter2 = New TeamProject.SHHDataSetFinalTableAdapters.DoctorsTableAdapter()
        Me.HandymanBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.HandymanTableAdapter = New TeamProject.SHHDataSetFinalTableAdapters.HandymanTableAdapter()
        Me.PatientsBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.PatientsTableAdapter = New TeamProject.SHHDataSetFinalTableAdapters.PatientsTableAdapter()
        Me.NursesTableAdapter2 = New TeamProject.SHHDataSetFinalTableAdapters.NursesTableAdapter()
        Me.btnCalcSalary = New System.Windows.Forms.Button()
        Me.txtSalaryTotal = New System.Windows.Forms.TextBox()
        Me.IDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NSurname = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NHead = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        CType(Me.dgvDoctors, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NursesBindingSource2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SHHDataSetFinal, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DoctorsBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataSetReal, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DoctorsBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SHHDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NursesBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NursesBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DoctorsBindingSource2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HandymanBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PatientsBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dgvDoctors
        '
        Me.dgvDoctors.AllowUserToAddRows = False
        Me.dgvDoctors.AllowUserToDeleteRows = False
        Me.dgvDoctors.AutoGenerateColumns = False
        Me.dgvDoctors.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvDoctors.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvDoctors.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.IDDataGridViewTextBoxColumn, Me.NName, Me.NSurname, Me.NHead})
        Me.dgvDoctors.DataSource = Me.NursesBindingSource2
        Me.dgvDoctors.Location = New System.Drawing.Point(3, 2)
        Me.dgvDoctors.Name = "dgvDoctors"
        Me.dgvDoctors.Size = New System.Drawing.Size(868, 443)
        Me.dgvDoctors.TabIndex = 1
        '
        'NursesBindingSource2
        '
        Me.NursesBindingSource2.DataMember = "Nurses"
        Me.NursesBindingSource2.DataSource = Me.SHHDataSetFinal
        '
        'SHHDataSetFinal
        '
        Me.SHHDataSetFinal.DataSetName = "SHHDataSetFinal"
        Me.SHHDataSetFinal.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'DoctorsBindingSource1
        '
        Me.DoctorsBindingSource1.DataMember = "Doctors"
        Me.DoctorsBindingSource1.DataSource = Me.DataSetReal
        '
        'DataSetReal
        '
        Me.DataSetReal.DataSetName = "DataSetReal"
        Me.DataSetReal.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'DoctorsBindingSource
        '
        Me.DoctorsBindingSource.DataMember = "Doctors"
        Me.DoctorsBindingSource.DataSource = Me.SHHDataSet
        '
        'SHHDataSet
        '
        Me.SHHDataSet.DataSetName = "SHHDataSet"
        Me.SHHDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'DoctorsTableAdapter
        '
        Me.DoctorsTableAdapter.ClearBeforeFill = True
        '
        'btnAddDoc
        '
        Me.btnAddDoc.Location = New System.Drawing.Point(157, 451)
        Me.btnAddDoc.Name = "btnAddDoc"
        Me.btnAddDoc.Size = New System.Drawing.Size(148, 23)
        Me.btnAddDoc.TabIndex = 2
        Me.btnAddDoc.Text = "Add Worker"
        Me.btnAddDoc.UseVisualStyleBackColor = True
        '
        'NursesBindingSource
        '
        Me.NursesBindingSource.DataMember = "Nurses"
        Me.NursesBindingSource.DataSource = Me.SHHDataSet
        '
        'NursesTableAdapter
        '
        Me.NursesTableAdapter.ClearBeforeFill = True
        '
        'btnMedications
        '
        Me.btnMedications.Location = New System.Drawing.Point(311, 450)
        Me.btnMedications.Name = "btnMedications"
        Me.btnMedications.Size = New System.Drawing.Size(134, 24)
        Me.btnMedications.TabIndex = 5
        Me.btnMedications.Text = "Medication"
        Me.btnMedications.UseVisualStyleBackColor = True
        '
        'btnGoBack
        '
        Me.btnGoBack.Location = New System.Drawing.Point(737, 450)
        Me.btnGoBack.Name = "btnGoBack"
        Me.btnGoBack.Size = New System.Drawing.Size(134, 24)
        Me.btnGoBack.TabIndex = 6
        Me.btnGoBack.Text = "Go Back"
        Me.btnGoBack.UseVisualStyleBackColor = True
        '
        'DoctorsTableAdapter1
        '
        Me.DoctorsTableAdapter1.ClearBeforeFill = True
        '
        'btnSwap
        '
        Me.btnSwap.Location = New System.Drawing.Point(3, 450)
        Me.btnSwap.Name = "btnSwap"
        Me.btnSwap.Size = New System.Drawing.Size(148, 23)
        Me.btnSwap.TabIndex = 7
        Me.btnSwap.Text = "Select Table"
        Me.btnSwap.UseVisualStyleBackColor = True
        '
        'NursesBindingSource1
        '
        Me.NursesBindingSource1.DataMember = "Nurses"
        Me.NursesBindingSource1.DataSource = Me.DataSetReal
        '
        'NursesTableAdapter1
        '
        Me.NursesTableAdapter1.ClearBeforeFill = True
        '
        'DoctorsBindingSource2
        '
        Me.DoctorsBindingSource2.DataMember = "Doctors"
        Me.DoctorsBindingSource2.DataSource = Me.SHHDataSetFinal
        '
        'DoctorsTableAdapter2
        '
        Me.DoctorsTableAdapter2.ClearBeforeFill = True
        '
        'HandymanBindingSource
        '
        Me.HandymanBindingSource.DataMember = "Handyman"
        Me.HandymanBindingSource.DataSource = Me.SHHDataSetFinal
        '
        'HandymanTableAdapter
        '
        Me.HandymanTableAdapter.ClearBeforeFill = True
        '
        'PatientsBindingSource
        '
        Me.PatientsBindingSource.DataMember = "Patients"
        Me.PatientsBindingSource.DataSource = Me.SHHDataSetFinal
        '
        'PatientsTableAdapter
        '
        Me.PatientsTableAdapter.ClearBeforeFill = True
        '
        'NursesTableAdapter2
        '
        Me.NursesTableAdapter2.ClearBeforeFill = True
        '
        'btnCalcSalary
        '
        Me.btnCalcSalary.Location = New System.Drawing.Point(477, 450)
        Me.btnCalcSalary.Name = "btnCalcSalary"
        Me.btnCalcSalary.Size = New System.Drawing.Size(134, 24)
        Me.btnCalcSalary.TabIndex = 8
        Me.btnCalcSalary.Text = "Calculate Salaries"
        Me.btnCalcSalary.UseVisualStyleBackColor = True
        '
        'txtSalaryTotal
        '
        Me.txtSalaryTotal.Location = New System.Drawing.Point(617, 453)
        Me.txtSalaryTotal.Name = "txtSalaryTotal"
        Me.txtSalaryTotal.Size = New System.Drawing.Size(114, 20)
        Me.txtSalaryTotal.TabIndex = 9
        '
        'IDDataGridViewTextBoxColumn
        '
        Me.IDDataGridViewTextBoxColumn.DataPropertyName = "ID"
        Me.IDDataGridViewTextBoxColumn.HeaderText = "ID"
        Me.IDDataGridViewTextBoxColumn.Name = "IDDataGridViewTextBoxColumn"
        '
        'NName
        '
        Me.NName.DataPropertyName = "NName"
        Me.NName.HeaderText = "NName"
        Me.NName.Name = "NName"
        '
        'NSurname
        '
        Me.NSurname.DataPropertyName = "NSurname"
        Me.NSurname.HeaderText = "NSurname"
        Me.NSurname.Name = "NSurname"
        '
        'NHead
        '
        Me.NHead.DataPropertyName = "NHead"
        Me.NHead.HeaderText = "NHead"
        Me.NHead.Name = "NHead"
        '
        'Staff
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(874, 492)
        Me.Controls.Add(Me.txtSalaryTotal)
        Me.Controls.Add(Me.btnCalcSalary)
        Me.Controls.Add(Me.btnSwap)
        Me.Controls.Add(Me.btnGoBack)
        Me.Controls.Add(Me.btnMedications)
        Me.Controls.Add(Me.btnAddDoc)
        Me.Controls.Add(Me.dgvDoctors)
        Me.Name = "Staff"
        Me.Text = "Staff"
        CType(Me.dgvDoctors, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NursesBindingSource2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SHHDataSetFinal, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DoctorsBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataSetReal, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DoctorsBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SHHDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NursesBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NursesBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DoctorsBindingSource2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HandymanBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PatientsBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents dgvDoctors As DataGridView
    Friend WithEvents SHHDataSet As SHHDataSet
    Friend WithEvents DoctorsBindingSource As BindingSource
    Friend WithEvents DoctorsTableAdapter As SHHDataSetTableAdapters.DoctorsTableAdapter
    Friend WithEvents btnAddDoc As Button
    Friend WithEvents NursesBindingSource As BindingSource
    Friend WithEvents NursesTableAdapter As SHHDataSetTableAdapters.NursesTableAdapter
    Friend WithEvents btnMedications As Button
    Friend WithEvents btnGoBack As Button
    Friend WithEvents DataSetReal As DataSetReal
    Friend WithEvents DoctorsBindingSource1 As BindingSource
    Friend WithEvents DoctorsTableAdapter1 As DataSetRealTableAdapters.DoctorsTableAdapter
    Friend WithEvents btnSwap As Button
    Friend WithEvents NursesBindingSource1 As BindingSource
    Friend WithEvents NursesTableAdapter1 As DataSetRealTableAdapters.NursesTableAdapter
    Friend WithEvents SHHDataSetFinal As SHHDataSetFinal
    Friend WithEvents DoctorsBindingSource2 As BindingSource
    Friend WithEvents DoctorsTableAdapter2 As SHHDataSetFinalTableAdapters.DoctorsTableAdapter
    Friend WithEvents HandymanBindingSource As BindingSource
    Friend WithEvents HandymanTableAdapter As SHHDataSetFinalTableAdapters.HandymanTableAdapter
    Friend WithEvents PatientsBindingSource As BindingSource
    Friend WithEvents PatientsTableAdapter As SHHDataSetFinalTableAdapters.PatientsTableAdapter
    Friend WithEvents NursesBindingSource2 As BindingSource
    Friend WithEvents NursesTableAdapter2 As SHHDataSetFinalTableAdapters.NursesTableAdapter
    Friend WithEvents btnCalcSalary As Button
    Friend WithEvents txtSalaryTotal As TextBox
    Friend WithEvents IDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents NName As DataGridViewTextBoxColumn
    Friend WithEvents NSurname As DataGridViewTextBoxColumn
    Friend WithEvents NHead As DataGridViewCheckBoxColumn
End Class
