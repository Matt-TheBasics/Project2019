﻿Option Explicit On
Option Infer Off
Option Strict On
Imports System.IO
Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs)
        Using writer As New StreamWriter("Login.txt")
            writer.WriteLine(txtn.Text & Environment.NewLine & txtp.Text) ' write the text via textbox/inputbox
        End Using
        MsgBox("Login successful")
        txtn.Clear() ' Clear textbox's
        txtp.Clear()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Code to Read data from file if you want it
        If File.Exists("Login.txt") Then
            Using reader As New StreamReader("Login.txt")
                txtn.Text = reader.ReadLine()
                txtp.Text = reader.ReadLine()
            End Using
        End If
    End Sub
End Class
