﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Add_staff
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnAddS = New System.Windows.Forms.Button()
        Me.txtID = New System.Windows.Forms.TextBox()
        Me.lblID = New System.Windows.Forms.Label()
        Me.lblDoB = New System.Windows.Forms.Label()
        Me.dtpDoB = New System.Windows.Forms.DateTimePicker()
        Me.txtSurname = New System.Windows.Forms.TextBox()
        Me.lblSurname = New System.Windows.Forms.Label()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.lblName = New System.Windows.Forms.Label()
        Me.lblPass = New System.Windows.Forms.Label()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.cbxJob = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnGoBack = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnAddS
        '
        Me.btnAddS.Location = New System.Drawing.Point(9, 167)
        Me.btnAddS.Name = "btnAddS"
        Me.btnAddS.Size = New System.Drawing.Size(392, 27)
        Me.btnAddS.TabIndex = 29
        Me.btnAddS.Text = "Add Staff Member"
        Me.btnAddS.UseVisualStyleBackColor = True
        '
        'txtID
        '
        Me.txtID.Location = New System.Drawing.Point(174, 84)
        Me.txtID.Name = "txtID"
        Me.txtID.Size = New System.Drawing.Size(227, 20)
        Me.txtID.TabIndex = 28
        '
        'lblID
        '
        Me.lblID.AutoSize = True
        Me.lblID.Location = New System.Drawing.Point(12, 87)
        Me.lblID.Name = "lblID"
        Me.lblID.Size = New System.Drawing.Size(64, 13)
        Me.lblID.TabIndex = 27
        Me.lblID.Text = "ID Number :"
        '
        'lblDoB
        '
        Me.lblDoB.AutoSize = True
        Me.lblDoB.Location = New System.Drawing.Point(12, 64)
        Me.lblDoB.Name = "lblDoB"
        Me.lblDoB.Size = New System.Drawing.Size(72, 13)
        Me.lblDoB.TabIndex = 26
        Me.lblDoB.Text = "Date of Birth :"
        '
        'dtpDoB
        '
        Me.dtpDoB.Location = New System.Drawing.Point(174, 58)
        Me.dtpDoB.MaxDate = New Date(2019, 10, 7, 0, 0, 0, 0)
        Me.dtpDoB.Name = "dtpDoB"
        Me.dtpDoB.Size = New System.Drawing.Size(227, 20)
        Me.dtpDoB.TabIndex = 25
        Me.dtpDoB.Value = New Date(2019, 10, 7, 0, 0, 0, 0)
        '
        'txtSurname
        '
        Me.txtSurname.Location = New System.Drawing.Point(174, 32)
        Me.txtSurname.Name = "txtSurname"
        Me.txtSurname.Size = New System.Drawing.Size(227, 20)
        Me.txtSurname.TabIndex = 19
        '
        'lblSurname
        '
        Me.lblSurname.AutoSize = True
        Me.lblSurname.Location = New System.Drawing.Point(12, 35)
        Me.lblSurname.Name = "lblSurname"
        Me.lblSurname.Size = New System.Drawing.Size(55, 13)
        Me.lblSurname.TabIndex = 18
        Me.lblSurname.Text = "Surname :"
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(174, 6)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(227, 20)
        Me.txtName.TabIndex = 17
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.Location = New System.Drawing.Point(12, 9)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(41, 13)
        Me.lblName.TabIndex = 16
        Me.lblName.Text = "Name :"
        '
        'lblPass
        '
        Me.lblPass.AutoSize = True
        Me.lblPass.Location = New System.Drawing.Point(12, 144)
        Me.lblPass.Name = "lblPass"
        Me.lblPass.Size = New System.Drawing.Size(119, 13)
        Me.lblPass.TabIndex = 30
        Me.lblPass.Text = "Head Nurse Password :"
        '
        'txtPassword
        '
        Me.txtPassword.Location = New System.Drawing.Point(174, 141)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.Size = New System.Drawing.Size(227, 20)
        Me.txtPassword.TabIndex = 31
        Me.txtPassword.UseSystemPasswordChar = True
        '
        'cbxJob
        '
        Me.cbxJob.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbxJob.FormattingEnabled = True
        Me.cbxJob.Items.AddRange(New Object() {"Doctor", "Nurse", "Handyman"})
        Me.cbxJob.Location = New System.Drawing.Point(174, 110)
        Me.cbxJob.Name = "cbxJob"
        Me.cbxJob.Size = New System.Drawing.Size(227, 21)
        Me.cbxJob.TabIndex = 32
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 113)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(53, 13)
        Me.Label1.TabIndex = 33
        Me.Label1.Text = "Job Title :"
        '
        'btnGoBack
        '
        Me.btnGoBack.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnGoBack.Location = New System.Drawing.Point(9, 200)
        Me.btnGoBack.Name = "btnGoBack"
        Me.btnGoBack.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.btnGoBack.Size = New System.Drawing.Size(392, 27)
        Me.btnGoBack.TabIndex = 34
        Me.btnGoBack.Text = "Go Back"
        Me.btnGoBack.UseVisualStyleBackColor = True
        '
        'Add_staff
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(414, 242)
        Me.Controls.Add(Me.btnGoBack)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cbxJob)
        Me.Controls.Add(Me.txtPassword)
        Me.Controls.Add(Me.lblPass)
        Me.Controls.Add(Me.btnAddS)
        Me.Controls.Add(Me.txtID)
        Me.Controls.Add(Me.lblID)
        Me.Controls.Add(Me.lblDoB)
        Me.Controls.Add(Me.dtpDoB)
        Me.Controls.Add(Me.txtSurname)
        Me.Controls.Add(Me.lblSurname)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.lblName)
        Me.Name = "Add_staff"
        Me.Text = "Add_staff"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnAddS As Button
    Friend WithEvents txtID As TextBox
    Friend WithEvents lblID As Label
    Friend WithEvents lblDoB As Label
    Friend WithEvents dtpDoB As DateTimePicker
    Friend WithEvents txtSurname As TextBox
    Friend WithEvents lblSurname As Label
    Friend WithEvents txtName As TextBox
    Friend WithEvents lblName As Label
    Friend WithEvents lblPass As Label
    Friend WithEvents txtPassword As TextBox
    Friend WithEvents cbxJob As ComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents btnGoBack As Button
End Class
