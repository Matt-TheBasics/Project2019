﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Add_Medication
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblName = New System.Windows.Forms.Label()
        Me.lblActive = New System.Windows.Forms.Label()
        Me.lblSchedule = New System.Windows.Forms.Label()
        Me.lblDate = New System.Windows.Forms.Label()
        Me.lblStock = New System.Windows.Forms.Label()
        Me.lblOther = New System.Windows.Forms.Label()
        Me.txtOther = New System.Windows.Forms.TextBox()
        Me.cbxIllness = New System.Windows.Forms.ComboBox()
        Me.lblIllness = New System.Windows.Forms.Label()
        Me.mcReceived = New System.Windows.Forms.MonthCalendar()
        Me.nudSchedule = New System.Windows.Forms.NumericUpDown()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.txtAcIg = New System.Windows.Forms.TextBox()
        Me.txtStock = New System.Windows.Forms.TextBox()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.btnBack = New System.Windows.Forms.Button()
        CType(Me.nudSchedule, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.Location = New System.Drawing.Point(8, 10)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(41, 13)
        Me.lblName.TabIndex = 1
        Me.lblName.Text = "Name :"
        '
        'lblActive
        '
        Me.lblActive.AutoSize = True
        Me.lblActive.Location = New System.Drawing.Point(9, 37)
        Me.lblActive.Name = "lblActive"
        Me.lblActive.Size = New System.Drawing.Size(93, 13)
        Me.lblActive.TabIndex = 2
        Me.lblActive.Text = "Active Ingredient :"
        '
        'lblSchedule
        '
        Me.lblSchedule.AutoSize = True
        Me.lblSchedule.Location = New System.Drawing.Point(8, 62)
        Me.lblSchedule.Name = "lblSchedule"
        Me.lblSchedule.Size = New System.Drawing.Size(58, 13)
        Me.lblSchedule.TabIndex = 3
        Me.lblSchedule.Text = "Schedule :"
        '
        'lblDate
        '
        Me.lblDate.AutoSize = True
        Me.lblDate.Location = New System.Drawing.Point(9, 92)
        Me.lblDate.Name = "lblDate"
        Me.lblDate.Size = New System.Drawing.Size(85, 13)
        Me.lblDate.TabIndex = 4
        Me.lblDate.Text = "Date Received :"
        '
        'lblStock
        '
        Me.lblStock.AutoSize = True
        Me.lblStock.Location = New System.Drawing.Point(9, 381)
        Me.lblStock.Name = "lblStock"
        Me.lblStock.Size = New System.Drawing.Size(89, 13)
        Me.lblStock.TabIndex = 5
        Me.lblStock.Text = "Stock remaining :"
        '
        'lblOther
        '
        Me.lblOther.AutoSize = True
        Me.lblOther.Location = New System.Drawing.Point(8, 296)
        Me.lblOther.Name = "lblOther"
        Me.lblOther.Size = New System.Drawing.Size(83, 13)
        Me.lblOther.TabIndex = 19
        Me.lblOther.Text = "Please Specify :"
        '
        'txtOther
        '
        Me.txtOther.Enabled = False
        Me.txtOther.Location = New System.Drawing.Point(132, 293)
        Me.txtOther.Multiline = True
        Me.txtOther.Name = "txtOther"
        Me.txtOther.Size = New System.Drawing.Size(227, 79)
        Me.txtOther.TabIndex = 18
        '
        'cbxIllness
        '
        Me.cbxIllness.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbxIllness.FormattingEnabled = True
        Me.cbxIllness.Items.AddRange(New Object() {"Human Immunodeficiency Virus (H.I.V.)", "Tuberculosis (TB)", "Other"})
        Me.cbxIllness.Location = New System.Drawing.Point(132, 266)
        Me.cbxIllness.Name = "cbxIllness"
        Me.cbxIllness.Size = New System.Drawing.Size(227, 21)
        Me.cbxIllness.TabIndex = 17
        '
        'lblIllness
        '
        Me.lblIllness.AutoSize = True
        Me.lblIllness.Location = New System.Drawing.Point(7, 269)
        Me.lblIllness.Name = "lblIllness"
        Me.lblIllness.Size = New System.Drawing.Size(42, 13)
        Me.lblIllness.TabIndex = 16
        Me.lblIllness.Text = "Illness :"
        '
        'mcReceived
        '
        Me.mcReceived.Location = New System.Drawing.Point(132, 92)
        Me.mcReceived.Name = "mcReceived"
        Me.mcReceived.TabIndex = 20
        '
        'nudSchedule
        '
        Me.nudSchedule.Location = New System.Drawing.Point(132, 60)
        Me.nudSchedule.Maximum = New Decimal(New Integer() {12, 0, 0, 0})
        Me.nudSchedule.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nudSchedule.Name = "nudSchedule"
        Me.nudSchedule.Size = New System.Drawing.Size(227, 20)
        Me.nudSchedule.TabIndex = 21
        Me.nudSchedule.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(132, 7)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(227, 20)
        Me.txtName.TabIndex = 22
        '
        'txtAcIg
        '
        Me.txtAcIg.Location = New System.Drawing.Point(132, 34)
        Me.txtAcIg.Name = "txtAcIg"
        Me.txtAcIg.Size = New System.Drawing.Size(227, 20)
        Me.txtAcIg.TabIndex = 23
        '
        'txtStock
        '
        Me.txtStock.Location = New System.Drawing.Point(132, 378)
        Me.txtStock.Name = "txtStock"
        Me.txtStock.Size = New System.Drawing.Size(227, 20)
        Me.txtStock.TabIndex = 24
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(10, 404)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(349, 24)
        Me.btnAdd.TabIndex = 25
        Me.btnAdd.Text = "Add medication"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'btnBack
        '
        Me.btnBack.Location = New System.Drawing.Point(10, 434)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(349, 24)
        Me.btnBack.TabIndex = 26
        Me.btnBack.Text = "Go back"
        Me.btnBack.UseVisualStyleBackColor = True
        '
        'Add_Medication
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(372, 468)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.txtStock)
        Me.Controls.Add(Me.txtAcIg)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.nudSchedule)
        Me.Controls.Add(Me.mcReceived)
        Me.Controls.Add(Me.lblOther)
        Me.Controls.Add(Me.txtOther)
        Me.Controls.Add(Me.cbxIllness)
        Me.Controls.Add(Me.lblIllness)
        Me.Controls.Add(Me.lblStock)
        Me.Controls.Add(Me.lblDate)
        Me.Controls.Add(Me.lblSchedule)
        Me.Controls.Add(Me.lblActive)
        Me.Controls.Add(Me.lblName)
        Me.Name = "Add_Medication"
        Me.Text = "Add_Medication"
        CType(Me.nudSchedule, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblName As Label
    Friend WithEvents lblActive As Label
    Friend WithEvents lblSchedule As Label
    Friend WithEvents lblDate As Label
    Friend WithEvents lblStock As Label
    Friend WithEvents lblOther As Label
    Friend WithEvents txtOther As TextBox
    Friend WithEvents cbxIllness As ComboBox
    Friend WithEvents lblIllness As Label
    Friend WithEvents mcReceived As MonthCalendar
    Friend WithEvents nudSchedule As NumericUpDown
    Friend WithEvents txtName As TextBox
    Friend WithEvents txtAcIg As TextBox
    Friend WithEvents txtStock As TextBox
    Friend WithEvents btnAdd As Button
    Friend WithEvents btnBack As Button
End Class
