﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Hospital
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.btnStaff = New System.Windows.Forms.Button()
        Me.btnPatient = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnStaff
        '
        Me.btnStaff.ImageAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.btnStaff.Location = New System.Drawing.Point(12, 31)
        Me.btnStaff.Name = "btnStaff"
        Me.btnStaff.Size = New System.Drawing.Size(171, 126)
        Me.btnStaff.TabIndex = 0
        Me.btnStaff.Text = "Staff login"
        Me.btnStaff.UseVisualStyleBackColor = True
        '
        'btnPatient
        '
        Me.btnPatient.Location = New System.Drawing.Point(189, 31)
        Me.btnPatient.Name = "btnPatient"
        Me.btnPatient.Size = New System.Drawing.Size(171, 126)
        Me.btnPatient.TabIndex = 1
        Me.btnPatient.Text = "Patient Login"
        Me.btnPatient.UseVisualStyleBackColor = True
        '
        'Hospital
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(367, 174)
        Me.Controls.Add(Me.btnPatient)
        Me.Controls.Add(Me.btnStaff)
        Me.Name = "Hospital"
        Me.Text = "Hospital"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnStaff As Button
    Friend WithEvents btnPatient As Button
End Class
