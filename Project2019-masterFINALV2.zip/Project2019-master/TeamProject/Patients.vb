﻿Imports System.IO


Public Class Patients
    Private Sub btnOther_CheckedChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub cbxIllness_DropDownClosed(sender As Object, e As EventArgs) Handles cbxIllness.DropDownClosed
        If (cbxIllness.SelectedIndex = 2) Then
            txtOther.Enabled = True
        End If
    End Sub

    Private Sub btnAddP_Click(sender As Object, e As EventArgs) Handles btnAddP.Click

        'Verify that the ID is valid

        'If not throw exception that tells user it isnt valid

        'Import all data to database

        Dim sName As String
        Dim sSurname As String
        Dim sDoB As String
        Dim sID As String
        Dim sAppointment As String

        sName = txtName.Text
        sSurname = txtSurname.Text
        sDoB = dtpDoB.Value.ToShortDateString()
        sID = txtID.Text
        sAppointment = mcApp.SelectionStart.ToShortDateString()




        If (validateID(sID) = True) Then
            Dim tempIDString As String = sID.Substring(0, 5)
            Dim tempDateString As String = sDoB.Replace("/", "")
            tempDateString = tempDateString.Substring(2, 6)
            If (tempDateString = tempIDString) Then
                Try
                    Dim sqlconn As New OleDb.OleDbConnection
                    Dim sqlquery As New OleDb.OleDbCommand
                    Dim connString As String
                    connString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=SHH.mdb"
                    sqlconn.ConnectionString = connString
                    sqlquery.Connection = sqlconn
                    sqlconn.Open()
                    Dim sPaid As String = InputBox("Has the person paid the deposit?")
                    Dim sSpecial As String
                    If (cbxIllness.SelectedIndex = 2) Then
                        sSpecial = "Yes"
                    Else
                        sSpecial = "No"
                    End If
                    sqlquery.CommandText = "INSERT INTO Patients([PName], [PSurname], [PID], [PDateOofBirth], [PPaid], [RSpec], [PAppointment])VALUES(@PName, @PSurname, @PID, @PDateOofBirth, @PPaid, @RSpec, @PAppointment)"
                    sqlquery.Parameters.AddWithValue("@PName", sName)
                    sqlquery.Parameters.AddWithValue("@PSurname", sSurname)
                    sqlquery.Parameters.AddWithValue("@PID", "sID")
                    sqlquery.Parameters.AddWithValue("@PDateOfBirth", "sDoB")
                    sqlquery.Parameters.AddWithValue("@PPaid", sPaid)
                    sqlquery.Parameters.AddWithValue("@RSpec", sSpecial)
                    sqlquery.Parameters.AddWithValue("@PAppointment", sAppointment)
                    sqlquery.ExecuteNonQuery()
                    sqlconn.Close()

                    MessageBox.Show("Patient added successfully!")
                Catch ex As Exception
                    MessageBox.Show(ex.Message)
                End Try

            End If
        Else

            MessageBox.Show("Please enter a valid ID!")
        End If

        Hospital.Visible = True
        Me.Close()
    End Sub

    Private Sub mcApp_DateSelected(sender As Object, e As DateRangeEventArgs) Handles mcApp.DateSelected
        '    'check if date is available and display a popup if not
        Dim count As Integer
        Try
            Dim sqlconn As New OleDb.OleDbConnection
            Dim sqlquery As New OleDb.OleDbCommand
            Dim connString As String
            connString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=SHH.mdb"
            sqlconn.ConnectionString = connString
            sqlquery.Connection = sqlconn
            sqlconn.Open()
            sqlquery.CommandText = "SELECT COUNT(*) FROM Patients WHERE PAppointment= '" & mcApp.SelectionStart.ToShortDateString() & "' "

            count = CInt(sqlquery.ExecuteScalar())
            sqlconn.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

        If count >= 5 Then
            MessageBox.Show("Please select another date!")
        Else
            MessageBox.Show("This date is available!")
        End If
    End Sub

    Private Sub btnGoBack_Click(sender As Object, e As EventArgs) Handles btnGoBack.Click
        'Me.Close()
    End Sub

    Private Function validateID(ByVal sID As String) As Boolean
        Try
            Dim a As Integer = 0
            For i As Integer = 0 To 5
                a += CInt(sID.Substring(i * 2, 1))
            Next

            Dim b As Integer = 0
            For i As Integer = 0 To 5
                b = b * 10 + CInt(sID.Substring(2 * i + 1, 1))
            Next
            b *= 2
            Dim c As Integer = 0
            Do
                c += b Mod 10
                b = Int(b / 10)
            Loop Until b <= 0
            c += a
            Dim d As Integer = 0
            d = 10 - (c Mod 10)
            If (d = 10) Then d = 0
            If d = CInt(sID.Substring(12, 1)) Then
                Return True
            Else
                Return False
            End If
        Catch
            Return False
        End Try
    End Function

    Private Sub mcApp_DateChanged(sender As Object, e As DateRangeEventArgs) Handles mcApp.DateChanged

    End Sub
End Class