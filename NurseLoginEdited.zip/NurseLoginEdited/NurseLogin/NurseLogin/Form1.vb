﻿Option Explicit On
Option Strict On
Option Infer Off
Imports System.IO
Public Class frmLogin
    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click

        Dim Username As String = "MadamBasic"
        Dim Password As String = "Y3Wa#2&q"

        If txtPassword.Text <> Password Or txtUsername.Text <> Username Then
            MsgBox("Wrong Password or Username!!!", MsgBoxStyle.Exclamation And MsgBoxStyle.RetryCancel, "Warning")
        Else
            Using writer As New StreamWriter("Login.txt")
                writer.Write(txtUsername.Text & Environment.NewLine & txtPassword.Text)
            End Using
            MsgBox("Login successful")
            txtUsername.Clear()
            txtPassword.Clear()
            MsgBox("Welcome Head Nurse!", MsgBoxStyle.OkOnly And MsgBoxStyle.Information)
        End If
    End Sub

    Private Sub btnForgot_Click(sender As Object, e As EventArgs) Handles btnForgot.Click
        Dim answer As String = InputBox("Type in your Master Password: Warning! you can only tpye this once")
        If answer = "Help101" Then
            If File.Exists("Login.txt") Then
                Using reader As New StreamReader("Login.txt")
                    txtUsername.Text = reader.ReadLine()
                    txtPassword.Text = reader.ReadLine()
                End Using
            End If
        Else
            MsgBox("Wrong Password!!!", MsgBoxStyle.Exclamation And MsgBoxStyle.RetryCancel, "Contact IT Assistance")
        End If
    End Sub
End Class
