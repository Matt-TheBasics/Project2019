﻿Imports System.Data.OleDb

Public Class Staff

    Dim daTables As OleDbDataAdapter
    Dim dsTables As DataSet
    Dim simpleC As Integer = 0

    Private Sub btnStaff_CheckedChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub Staff_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'SHHDataSetFinal.Nurses' table. You can move, or remove it, as needed.
        Me.NursesTableAdapter2.Fill(Me.SHHDataSetFinal.Nurses)



    End Sub

    Private Sub btnAddDoc_Click(sender As Object, e As EventArgs) Handles btnAddDoc.Click
        Add_staff.ShowDialog()
    End Sub

    Private Sub btnDorN_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub btnMedications_Click(sender As Object, e As EventArgs) Handles btnMedications.Click
        Medications.ShowDialog()
    End Sub

    Private Sub btnGoBack_Click(sender As Object, e As EventArgs) Handles btnGoBack.Click
        Me.Close()
    End Sub

    Private Sub btnSwap_Click(sender As Object, e As EventArgs) Handles btnSwap.Click
        If (simpleC Mod 2 = 0) Then
            'TODO: This line of code loads data into the 'SHHDataSetFinal.Doctors' table. You can move, or remove it, as needed.
            Me.DoctorsTableAdapter2.Fill(Me.SHHDataSetFinal.Doctors)
            dgvDoctors.Update()
        ElseIf (simpleC Mod 3 = 0) Then
            'TODO: This line of code loads data into the 'SHHDataSetFinal.Handyman' table. You can move, or remove it, as needed.
            Me.HandymanTableAdapter.Fill(Me.SHHDataSetFinal.Handyman)
            dgvDoctors.Update()
        Else
            Me.NursesTableAdapter2.Fill(Me.SHHDataSetFinal.Nurses)
            dgvDoctors.Update()
        End If
        simpleC += 1

    End Sub
End Class