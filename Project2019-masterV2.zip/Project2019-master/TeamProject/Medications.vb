﻿Public Class Medications
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Add_Medication.ShowDialog()
        DataGridView1.Refresh()

    End Sub

    Private Sub btnGoBack_Click(sender As Object, e As EventArgs) Handles btnGoBack.Click
        'Go back to previous window
        Me.Close()
    End Sub

    Private Sub Medications_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DataSetReal.Medication' table. You can move, or remove it, as needed.
        Me.MedicationTableAdapter.Fill(Me.DataSetReal.Medication)
        'Load table from database to display in the grid view
    End Sub
End Class