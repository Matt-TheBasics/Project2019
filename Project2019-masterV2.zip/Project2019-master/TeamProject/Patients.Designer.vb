﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Patients
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.lblPName = New System.Windows.Forms.Label()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.txtSurname = New System.Windows.Forms.TextBox()
        Me.lblPSurname = New System.Windows.Forms.Label()
        Me.lblAppointment = New System.Windows.Forms.Label()
        Me.lblIllness = New System.Windows.Forms.Label()
        Me.mcApp = New System.Windows.Forms.MonthCalendar()
        Me.cbxIllness = New System.Windows.Forms.ComboBox()
        Me.txtOther = New System.Windows.Forms.TextBox()
        Me.dtpDoB = New System.Windows.Forms.DateTimePicker()
        Me.lblDoB = New System.Windows.Forms.Label()
        Me.txtID = New System.Windows.Forms.TextBox()
        Me.lblID = New System.Windows.Forms.Label()
        Me.btnAddP = New System.Windows.Forms.Button()
        Me.lblOther = New System.Windows.Forms.Label()
        Me.btnGoBack = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblPName
        '
        Me.lblPName.AutoSize = True
        Me.lblPName.Location = New System.Drawing.Point(12, 14)
        Me.lblPName.Name = "lblPName"
        Me.lblPName.Size = New System.Drawing.Size(41, 13)
        Me.lblPName.TabIndex = 0
        Me.lblPName.Text = "Name :"
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(128, 11)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(227, 20)
        Me.txtName.TabIndex = 1
        '
        'txtSurname
        '
        Me.txtSurname.Location = New System.Drawing.Point(128, 37)
        Me.txtSurname.Name = "txtSurname"
        Me.txtSurname.Size = New System.Drawing.Size(227, 20)
        Me.txtSurname.TabIndex = 3
        '
        'lblPSurname
        '
        Me.lblPSurname.AutoSize = True
        Me.lblPSurname.Location = New System.Drawing.Point(12, 40)
        Me.lblPSurname.Name = "lblPSurname"
        Me.lblPSurname.Size = New System.Drawing.Size(55, 13)
        Me.lblPSurname.TabIndex = 2
        Me.lblPSurname.Text = "Surname :"
        '
        'lblAppointment
        '
        Me.lblAppointment.AutoSize = True
        Me.lblAppointment.Location = New System.Drawing.Point(12, 124)
        Me.lblAppointment.Name = "lblAppointment"
        Me.lblAppointment.Size = New System.Drawing.Size(98, 13)
        Me.lblAppointment.TabIndex = 4
        Me.lblAppointment.Text = "Appointment Date :"
        '
        'lblIllness
        '
        Me.lblIllness.AutoSize = True
        Me.lblIllness.Location = New System.Drawing.Point(12, 296)
        Me.lblIllness.Name = "lblIllness"
        Me.lblIllness.Size = New System.Drawing.Size(42, 13)
        Me.lblIllness.TabIndex = 6
        Me.lblIllness.Text = "Illness :"
        '
        'mcApp
        '
        Me.mcApp.Location = New System.Drawing.Point(128, 121)
        Me.mcApp.Name = "mcApp"
        Me.mcApp.TabIndex = 7
        '
        'cbxIllness
        '
        Me.cbxIllness.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbxIllness.FormattingEnabled = True
        Me.cbxIllness.Items.AddRange(New Object() {"Human Immunodeficiency Virus (H.I.V.)", "Tuberculosis (TB)", "Other"})
        Me.cbxIllness.Location = New System.Drawing.Point(128, 293)
        Me.cbxIllness.Name = "cbxIllness"
        Me.cbxIllness.Size = New System.Drawing.Size(227, 21)
        Me.cbxIllness.TabIndex = 8
        '
        'txtOther
        '
        Me.txtOther.Enabled = False
        Me.txtOther.Location = New System.Drawing.Point(128, 320)
        Me.txtOther.Multiline = True
        Me.txtOther.Name = "txtOther"
        Me.txtOther.Size = New System.Drawing.Size(227, 79)
        Me.txtOther.TabIndex = 9
        '
        'dtpDoB
        '
        Me.dtpDoB.Location = New System.Drawing.Point(128, 63)
        Me.dtpDoB.MaxDate = New Date(2019, 10, 7, 0, 0, 0, 0)
        Me.dtpDoB.Name = "dtpDoB"
        Me.dtpDoB.Size = New System.Drawing.Size(227, 20)
        Me.dtpDoB.TabIndex = 10
        Me.dtpDoB.Value = New Date(2019, 10, 7, 0, 0, 0, 0)
        '
        'lblDoB
        '
        Me.lblDoB.AutoSize = True
        Me.lblDoB.Location = New System.Drawing.Point(12, 69)
        Me.lblDoB.Name = "lblDoB"
        Me.lblDoB.Size = New System.Drawing.Size(72, 13)
        Me.lblDoB.TabIndex = 11
        Me.lblDoB.Text = "Date of Birth :"
        '
        'txtID
        '
        Me.txtID.Location = New System.Drawing.Point(128, 89)
        Me.txtID.Name = "txtID"
        Me.txtID.Size = New System.Drawing.Size(227, 20)
        Me.txtID.TabIndex = 13
        '
        'lblID
        '
        Me.lblID.AutoSize = True
        Me.lblID.Location = New System.Drawing.Point(12, 92)
        Me.lblID.Name = "lblID"
        Me.lblID.Size = New System.Drawing.Size(64, 13)
        Me.lblID.TabIndex = 12
        Me.lblID.Text = "ID Number :"
        '
        'btnAddP
        '
        Me.btnAddP.Location = New System.Drawing.Point(12, 405)
        Me.btnAddP.Name = "btnAddP"
        Me.btnAddP.Size = New System.Drawing.Size(346, 27)
        Me.btnAddP.TabIndex = 14
        Me.btnAddP.Text = "Add Patient"
        Me.btnAddP.UseVisualStyleBackColor = True
        '
        'lblOther
        '
        Me.lblOther.AutoSize = True
        Me.lblOther.Location = New System.Drawing.Point(12, 323)
        Me.lblOther.Name = "lblOther"
        Me.lblOther.Size = New System.Drawing.Size(83, 13)
        Me.lblOther.TabIndex = 15
        Me.lblOther.Text = "Please Specify :"
        '
        'btnGoBack
        '
        Me.btnGoBack.Location = New System.Drawing.Point(12, 438)
        Me.btnGoBack.Name = "btnGoBack"
        Me.btnGoBack.Size = New System.Drawing.Size(346, 27)
        Me.btnGoBack.TabIndex = 16
        Me.btnGoBack.Text = "Go back"
        Me.btnGoBack.UseVisualStyleBackColor = True
        '
        'Patients
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(372, 473)
        Me.Controls.Add(Me.btnGoBack)
        Me.Controls.Add(Me.lblOther)
        Me.Controls.Add(Me.btnAddP)
        Me.Controls.Add(Me.txtID)
        Me.Controls.Add(Me.lblID)
        Me.Controls.Add(Me.lblDoB)
        Me.Controls.Add(Me.dtpDoB)
        Me.Controls.Add(Me.txtOther)
        Me.Controls.Add(Me.cbxIllness)
        Me.Controls.Add(Me.mcApp)
        Me.Controls.Add(Me.lblIllness)
        Me.Controls.Add(Me.lblAppointment)
        Me.Controls.Add(Me.txtSurname)
        Me.Controls.Add(Me.lblPSurname)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.lblPName)
        Me.Name = "Patients"
        Me.Text = "Patients"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblPName As Label
    Friend WithEvents txtName As TextBox
    Friend WithEvents txtSurname As TextBox
    Friend WithEvents lblPSurname As Label
    Friend WithEvents lblAppointment As Label
    Friend WithEvents lblIllness As Label
    Friend WithEvents mcApp As MonthCalendar
    Friend WithEvents cbxIllness As ComboBox
    Friend WithEvents txtOther As TextBox
    Friend WithEvents dtpDoB As DateTimePicker
    Friend WithEvents lblDoB As Label
    Friend WithEvents txtID As TextBox
    Friend WithEvents lblID As Label
    Friend WithEvents btnAddP As Button
    Friend WithEvents lblOther As Label
    Friend WithEvents btnGoBack As Button
End Class
